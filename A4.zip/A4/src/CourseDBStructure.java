import java.io.IOException;
import java.util.*;

public class CourseDBStructure implements CourseDBStructureInterface {
        protected int size;
        protected LinkedList<CourseDBElement> hashTable[];
        
        @SuppressWarnings("unchecked")
        public CourseDBStructure(int s) {
                hashTable = new LinkedList[s];
        }
 
        @SuppressWarnings("unchecked")
        public CourseDBStructure(String testing, int s) {
                hashTable = new LinkedList[s];
        }

        public void add(CourseDBElement element) {
            int index =  element.hashCode() % size;
                if(hashTable[index] == null) {
                        hashTable[index] = new LinkedList<CourseDBElement>();
                        hashTable[index].add(element);
                }
                else {
                	hashTable[index].add(element);
                	}
        }

        @SuppressWarnings("unused")
		public CourseDBElement get(int crn) throws IOException {
                String s = String.valueOf(crn);
                int index = s.hashCode() % size;
                if(hashTable[index] == null) {
                        throw new IOException();
                }
                else {
                        for(int i = 0; i < size; i++) {
                                CourseDBElement temp = hashTable[index].get(i);
                                return temp;
                                
                        }
                        return null;
                }
        }

        public int getTableSize() {
                return size;
        }

}