import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {
	 private CourseDBStructure cds;

	  public CourseDBManager() {
	    cds = new CourseDBStructure(30);
	  }
 
        public void add(String ID, int crn, int Credits, String room, String instructor) {

        		CourseDBElement element = new CourseDBElement(ID, crn, Credits, room, instructor);
                cds.add(element);
        }
 
        public CourseDBElement get(int crn) {
                try {
                        return cds.get(crn);
                } catch (IOException e) {
                        e.getMessage();
                }
                return null;
        }


        public void readFile(File input) throws FileNotFoundException {
        	 try {
                 Scanner data = new Scanner(input);
                 String ID = data.next();
                 String room = data.next();
                 String instructor = data.nextLine();
                 int crn = data.nextInt();
                 int Credits = data.nextInt();
                 
                 while(data.hasNext()) {
                         add(ID, crn, Credits, room, instructor);
                 }
                 data.close();
         }
         catch(FileNotFoundException e) {
                 System.out.print("File is not exist");
                 e.getMessage();
         }
        }

 
        public ArrayList<String> showAll() {
        	
                ArrayList<String> list = new ArrayList<String>();
                
                for (int i = 0; i < cds.hashTable.length; i++) { 
                	
                        LinkedList<CourseDBElement> temp = cds.hashTable[i];
                        
                        if(temp != null) {
                                
                        	for(int x = 0; x < temp.size(); x++) { 
                                        
                        		CourseDBElement infor = temp.get(x);
                                        
                        		list.add(infor.toString());
                                }
                        }
                }
                return list;
        }

}
