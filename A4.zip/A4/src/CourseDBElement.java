public class CourseDBElement implements Comparable{
        private String ID;
        private int crn;
        private int Credits;
        private String room;
        private String instructor;

        public CourseDBElement() {
                ID = "";
                crn = 0;
                Credits = 0;
                room = "";
                instructor = "";
        }
 
        public CourseDBElement(String ID, int crn, int Credits, String room, String instructor) {
                this.ID = ID;
                this.crn = crn;
                this.Credits = Credits;
                this.room = room;
                this.instructor = instructor;
        }

        public int compareTo(CourseDBElement element) {
                return (this.crn - element.crn);
        }

        public String getID() {
            return ID;
          }


          public void setID(String ID) {
            this.ID = ID;
          }

        public int getCrn() {
                return crn;
        }

        public void setCrn(int crn) {
                this.crn = crn;
        }
        public int getCredits() {
            return Credits;
          }


        public void setCredits(int Credits) {
            this.Credits = Credits;
          }
        
        public String getRoom() {
        	    return room;
        	    }


        public void setRoom(String room) {
        	    this.room = room;
        	  }
        
        public String getInstructor() {
        	    return instructor;
        	  }


        public void setInstructor(String instructor) {
        	    this.instructor = instructor;
        	  }

        public int hashCode() {
                String s = String.valueOf(getCrn());
                return s.hashCode();
        }

        public boolean equals(Object obj) {
                if (this == obj)
                        return true;
                if (obj == null)
                        return false;
                if (!(obj instanceof CourseDBElement))
                        return false;
                CourseDBElement object = (CourseDBElement) obj;
                if (crn != object.crn)
                        return false;
                return true;
        }

        public String toString() {
                return "\nCourse:" + ID + " CRN:" + crn + " Credits:" + Credits + " Instructor:" + instructor + " Room:" + roomNum;
                
        }
        
}