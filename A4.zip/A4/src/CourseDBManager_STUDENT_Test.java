import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CourseDBManager_STUDENT_Test {
        private CourseDBManagerInterface manager = new CourseDBManager();
        @BeforeEach
        void setUp() throws Exception {
                manager = new CourseDBManager();
        }

        @AfterEach
        void tearDown() throws Exception {
        	manager = null;
        }

        @Test
        void testAddToDB() {
                try {
                	manager.add("CMSC204",202130,4,"COVID-19 Remote Classes","Khandan Vahabzadeh Monshi");
                }
                catch(Exception e) {
                        fail("This should not have caused an Exception");
                }
        }
        
        @Test
        void testShowAll() {
        	manager.add("CMSC204",202130,4,"COVID-19 Remote Classes","Khandan Vahabzadeh Monshi");
        	manager.add("CMSC204",202130,4,"COVID-19 Remote Classes","Other");
                ArrayList<String> list = manager.showAll();
                
                assertEquals(list.get(0),"\nCourse:CMSC204 CRN:202130 Credits:4 Instructor:Khandan Vahabzadeh Monshi Room:COVID-19 Remote Classes");
                assertEquals(list.get(1),"\nCourse:CMSC204 CRN:202130 Credits:4 Instructor:Other Room:COVID-19 Remote Classes");
        }
        
        @Test
        void testReadFile() {
                try {
                        File inputFile = new File("Test1.txt");
                        PrintWriter inFile = new PrintWriter(inputFile);
                        inFile.println("CMSC204 202130 4 COVID-19 Remote Classes Khandan Vahabzadeh Monshi");
                        inFile.print("CMSC204 202130 4 COVID-19 Remote Classes Other");
                        inFile.close();
                        manager.readFile(inputFile);
                } catch (Exception e) {
                        fail("Should not have thrown an exception");
                }
        }

}
}